#include"estruturas.c"
#include"estruturas_elf.c"

extern void fechaarquivos();
extern void desmontar();
extern void desmontarcomdebug();
extern void geratabela();
extern labelS *geracodigo();
extern labelS *geracodigocomdebug();
extern char *gerarlabel();
extern tabelaS *buscartabela();
extern labelS *buscarlabel();
extern void imprimecodigo();
extern void imprimenatela();
