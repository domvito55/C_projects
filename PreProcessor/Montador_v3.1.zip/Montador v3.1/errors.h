/**
Header para errors.c

@author Murilo Marques Marinho
@version 1.0
*/
#ifndef ERRORS_HEADER_GUARD
#define ERRORS_HEADER_GUARD

void error(int errorCode);

#endif
