/**
Cabeçalho preProcessor.c

@author Murilo Marques Marinho
@version 1.1
*/

#ifndef PREPROCESSOR_HEADER_GUARD
#define PREPROCESSOR_HEADER_GUARD

int preProcess(FILE** arquivo);

#endif
