/*cabecalho do arquivo funcmice.c*/

extern int conta(int *opercao, FILE **arquivo, char *c, FILE **temp);
extern int TransformToDecimal(int *operacao, FILE **arquivo, char *c, FILE **temp);

